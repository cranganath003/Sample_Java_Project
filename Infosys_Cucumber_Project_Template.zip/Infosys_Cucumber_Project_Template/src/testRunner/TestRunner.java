/**
* Class Description: This class is created to run required cucumber feature files.
* Test Script Id : TestRunner
* Author : 
* Version : V1.0
* Reviewed By : 
* Date of Creation : 
 */
package testRunner;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.runner.RunWith;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/*import atu.alm.wrapper.ALMServiceWrapper;
import atu.alm.wrapper.enums.StatusAs;
import atu.alm.wrapper.exceptions.ALMServiceException;*/

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

// Specify the feature file path in the features = " <feature file path> " section. 
@RunWith(Cucumber.class)
@CucumberOptions(features = "", glue = { "businessLogic" }, plugin = { "com.cucumber.listener.ExtentCucumberFormatter:" })

public class TestRunner {

	// Initialization of logger and report variables for Extent Reports
	public static ExtentTest logger;
	public static ExtentReports report;

	// Initialization of TestNGCucumberRunner Class
	TestNGCucumberRunner testNGCucumberRunner;

	// Initialize the web driver
	public static WebDriver driver;

	// The annotated method will be run only once before the first test method
	// in the current class is invoked. Extent Reports are initialized in this method.
	@BeforeClass(alwaysRun = true)

	public void setUpClass() throws Exception {

		// Initialize extent report files
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());

		Calendar currentDate1 = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MMM/dd HH:mm:ss");
		String dateN = formatter.format(currentDate1.getTime()).replace("/", "_");
		String dateNow = dateN.replace(":", "_");
		report = new ExtentReports(System.getProperty("user.dir") + "\\Reports\\ExtentReport_" + dateNow + ".html");
	}
	
	// The annotated method will be run before each test method. This method initializes the browser's driver instance.
	@BeforeMethod

	// Pass parameters to a @Test method.The parameter value decides the browser type to run the tests.
	@Parameters({ "browser" })
	public void setup(String browser) throws Exception {

		// Check if parameter passed as 'chrome' to run tests in Google Chrome Browser
		if (browser.equalsIgnoreCase("chrome")) {
			File chromeDriver = new File(System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", chromeDriver.getAbsolutePath());
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized", "--disable-extensions");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(capabilities);
		}

		// Check if parameter passed as 'ie' to run tests in Internet Explorer
		else if (browser.equalsIgnoreCase("ie")) {
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			File IEDriver = new File(System.getProperty("user.dir") + "\\Drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", IEDriver.getAbsolutePath());
			driver = new InternetExplorerDriver(capabilities);
			driver.manage().window().maximize();
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	// Runs every cucumber detected feature as separated test
	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature) {
		String x1 = cucumberFeature.getCucumberFeature().getPath();
		String[] x3 = x1.split(".fea");
		logger = report.startTest(x3[0]);
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}

	// Returns two dimensional array of CucumberFeatureWrapper objects.
	@DataProvider
	public Object[][] features() {
		return testNGCucumberRunner.provideFeatures();
	}

	// The annotated method will be run after each test method. This takes the
	// screen shot after each test method and writes it to Extent Report.
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException {

		// Gets current system time stamp which is appended to the generated
		// extent report file name
		Calendar currentDate1 = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MMM/dd HH:mm:ss");
		String dateN = formatter.format(currentDate1.getTime()).replace("/", "_");
		String dateNow = dateN.replace(":", "_");

		// Screen shot is captured on Scenario failure
		if (result.getStatus() == ITestResult.FAILURE) {
			String yourfilepath = System.getProperty("user.dir") + "\\Screenshots\\";
			File snapshort_file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(snapshort_file, new File(yourfilepath + dateNow + "test.png"));
			String image = logger.addScreenCapture(yourfilepath + dateNow + "test.png");
			logger.log(LogStatus.FAIL, "Scenario Failure" + image + result.getName());
			report.endTest(logger);
			report.flush();
		}

		// Screen shot is captured on Scenario success
		else {
			String yourfilepath = System.getProperty("user.dir") + "\\Screenshots\\";
			File snapshort_file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(snapshort_file, new File(yourfilepath + dateNow + "test.png"));
			String image = logger.addScreenCapture(yourfilepath + dateNow + "test.png");
			logger.log(LogStatus.PASS, "Scenario Success" + image);
			report.endTest(logger);
			report.flush();
		}
		driver.quit();
	}

	// The annotated method will be run only once after all the test methods in
	// the current class have run.
	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
	}
}