/**
* Class Description: This class is created to run required cucumber feature files.
* Test Script Id : TestRunner
* Author : Chintana
* Version : V1.0
* Reviewed By : Kalyan Manda
* Date of Creation : 
 */
package testRunner;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.runner.RunWith;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/*import atu.alm.wrapper.ALMServiceWrapper;
import atu.alm.wrapper.enums.StatusAs;
import atu.alm.wrapper.exceptions.ALMServiceException;*/

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

/**
 * annotation @RunWith runs the Cucumber tests with options specified under annotation @CucumberOptions 
 */
@RunWith(Cucumber.class)
@CucumberOptions(features = "", glue = { "businessLogic" }, plugin = {
		"com.cucumber.listener.ExtentCucumberFormatter:" })
public class TestRunner {

	// Initialization of logger and report variables for Extent Reports
	public static ExtentTest logger;
	public static ExtentReports report;

	// Initialization of TestNGCucumberRunner Class
	TestNGCucumberRunner testNGCucumberRunner;

	// Initialize the web driver
	public static WebDriver driver;

	/**
	 * @method: Extent Reports are initialized
	 * annotation @BeforeClass will be the first method that is run
	 * @param: none
	 * @return: void
	 */
	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		Calendar currentDate1 = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MMM/dd HH:mm:ss");
		String dateN = formatter.format(currentDate1.getTime()).replace("/", "_");
		String dateNow = dateN.replace(":", "_");
		report = new ExtentReports(System.getProperty("user.dir") + "\\Reports\\ExtentReport_" + dateNow + ".html");
	}

	/**
	 * @method setup: Initializes the browser's driver instance
	 * annotation @BeforeMethod  will be run once before every test method 
	 * @param: browser decides the browser type to run the tests
	 * @return: void
	 */
	@BeforeMethod
	@Parameters({ "browser" })
	public void setup(String browser) throws Exception {

		if (browser.equalsIgnoreCase("chrome")) {
			File chromeDriver = new File(System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", chromeDriver.getAbsolutePath());
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized", "--disable-extensions");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(options);
		}

		else if (browser.equalsIgnoreCase("ie")) {
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			File IEDriver = new File(System.getProperty("user.dir") + "\\Drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", IEDriver.getAbsolutePath());
			driver = new InternetExplorerDriver(capabilities);
			driver.manage().window().maximize();
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	/** 
	 * @method feature: Runs every cucumber detected feature as separated test
	 * annotation @Test identifies method to be run as TestNG test
	 * @param feature file in run
	 * @return void
	 * */
	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature) {
		String x1 = cucumberFeature.getCucumberFeature().getPath();
		String[] x3 = x1.split(".fea");
		logger = report.startTest(x3[0]);
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}

	/**
	 * @method features: feature files to be run are specified by this method
	 * @param none
	 * @return: two dimensional object array of CucumberFeatureWrapper
	 * */
	@DataProvider
	public Object[][] features() {
		return testNGCucumberRunner.provideFeatures();
	}

	/**
	 * @method tearDown: This annotated method will be run after each test method. This takes the
	 * screen shot after each test method and writes it to Extent Report. Gets
	 * current system time stamp which is appended to the generated extent
	 * report file name. Screen shot is captured on Scenario success OR
	 * Screen shot is captured on Scenario failure
	 * annotation @AfterMethod will be run once after every test method
	 * @param result - execution result of the test case in run will be stored in this variable
	 * @return void
	 */
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException {

		Calendar currentDate1 = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MMM/dd HH:mm:ss");
		String dateN = formatter.format(currentDate1.getTime()).replace("/", "_");
		String dateNow = dateN.replace(":", "_");

		if (result.getStatus() == ITestResult.FAILURE) {
			String yourfilepath = System.getProperty("user.dir") + "\\Screenshots\\";
			File snapshort_file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(snapshort_file, new File(yourfilepath + dateNow + "test.png"));
			String image = logger.addScreenCapture(yourfilepath + dateNow + "test.png");
			logger.log(LogStatus.FAIL, "Scenario Failure" + image + result.getName());
			report.endTest(logger);
			report.flush();
		}

		else {
			String yourfilepath = System.getProperty("user.dir") + "\\Screenshots\\";
			File snapshort_file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(snapshort_file, new File(yourfilepath + dateNow + "test.png"));
			String image = logger.addScreenCapture(yourfilepath + dateNow + "test.png");
			logger.log(LogStatus.PASS, "Scenario Success" + image);
			report.endTest(logger);
			report.flush();
		}
		driver.quit();
	}

	/**
	 * @method tearDownClass: method ends the testNGCucumberRunner 
	 * annotation @AfterClass will run only once after all the tests are executed
	 * @param none
	 * @return void
	 */
	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
	}
}